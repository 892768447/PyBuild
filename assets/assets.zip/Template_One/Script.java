// Copyright 2010 Google Inc. All Rights Reserved.

package $packagename$;

import android.content.Context;

public class Script {

	public static final String sFileName = "script.py";

	public static String getFileName(Context context) {
		return sFileName;
	}

	public static String getFileExtension(Context context) {
		if (sFileName == null) {
			getFileName(context);
		}
		int dotIndex = sFileName.lastIndexOf('.');
		if (dotIndex == -1) {
			return null;
		}
		return sFileName.substring(dotIndex);
	}

}
