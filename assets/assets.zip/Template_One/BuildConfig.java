package $packagename$;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}