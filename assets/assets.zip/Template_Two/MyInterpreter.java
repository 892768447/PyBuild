package $packagename$;

import com.googlecode.android_scripting.interpreter.Interpreter;

public class MyInterpreter {

	private Interpreter interpreter;

	public MyInterpreter(Interpreter interpreter) {
		this.interpreter = interpreter;
	}

	public Interpreter getInterpreter() {
		return this.interpreter;
	}

	// public List<String> getArguments() {
	// return this.interpreter.getArguments();
	// }

}
